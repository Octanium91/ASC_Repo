To download "Android Script Creator" you must run the file "ASCD.exe".

Could not download?
Mirrors:
http://sourceforge.net/projects/androidscript/
https://mega.nz/#F!rYVFySyY!v_2EpVSWEAZEYWkwEeKtdg

Contact e-mail - asc.feedback.os@gmail.com

Made in Ukraine