For start "Android Script Creator" you must run the file "ASC.exe".

[Requirements for Windows:]
Systems: Windows XP/Vista/7/8/8.1/10 x86\x64
Hard disk space: 200 mb
Installed Java JDK x86 (i586) (is not necessarily)
Not a long path to the program (Java will stop signing)

[Requirements for Linux:]
Systems: Ubuntu, Red Hat, CentOS, Fedora, Suse, Slackware, FreeBSD x86\x64 (anywhere can run Wine)
You must install Wine, from the site www.winehq.org or from application manager
Hard disk space: 200 mb
Not a long path to the program (Java will stop signing)

[Requirements for MAC OS X:]
Systems: Darwin, Mac OS X x86\x64
You must install Wine, from the site www.winehq.org / (sourceforge.net/projects/darwine) or from application manager
Hard disk space: 200 mb
Not a long path to the program (Java will stop signing)

[Requirements for Solaris:]
Systems: Solaris
You must install Wine, from the site www.winehq.org or from application manager
Hard disk space: 200 mb
Not a long path to the program (Java will stop signing)

ATTENTION: under Wine Android Script Creator work not absolutely stable, such false operation block "check for updates" (in the settings you can disable the check for updates! the problem will be solved), and ADB Panel probably does not work, BUT! build script\opening scripts\firmware\repacking firmware all this works fine! =)

Future versions of the program, i make the program better!

You can support me (Donate) - sites.google.com/site/androidscriptcreator/donate
Contact e-mail - asc.feedback.os@gmail.com

Made in Ukraine